
#Deployment code

import streamlit as st
import cv2
import numpy as np
from PIL import Image
from ultralytics import YOLO

st.set_page_config(page_title="Object Detection", layout="wide")
st.title("🚀 YOLOv8 Object Detection")

@st.cache_resource
def load_model():
    return YOLO("C:/Users/Hp/Downloads/best.pt")

model = load_model()

def detect_objects(image, model):
    image_array = cv2.cvtColor(np.array(image), cv2.COLOR_RGB2BGR)
    results = model(image_array)

    # Initialize counts for cylinders and shock absorbers
    class_counts = {"cylinders": 0, "shock-absorber": 0}

    for result in results:
        for box in result.boxes:
            x1, y1, x2, y2 = map(int, box.xyxy[0])
            cls_id = int(box.cls[0].item())
            label = model.names.get(cls_id, "Unknown").lower()

            if label in class_counts:
                class_counts[label] += 1

            cv2.rectangle(image_array, (x1, y1), (x2, y2), (0, 255, 0), 2)
            cv2.putText(image_array, label, (x1, y1 - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)

    total_objects = sum(class_counts.values())
    return class_counts, total_objects, cv2.resize(image_array, (800, 500))

# Application UI
uploaded_file = st.file_uploader("📤 Upload an Image", type=["jpg", "png", "jpeg"])

if uploaded_file:
    image = Image.open(uploaded_file)
    class_counts, total_objects, detected_image = detect_objects(image, model)

    st.write("### Object Detection Results")
    st.write(f"- Cylinders: {class_counts['cylinders']}")
    st.write(f"- Shock Absorbers: {class_counts['shock-absorber']}")
    st.write(f"- **Total Objects Detected:** {total_objects}")
    st.image(detected_image)
