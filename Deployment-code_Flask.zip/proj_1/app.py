import os
import cv2
import numpy as np
import supervision as sv
from flask import Flask, request, render_template, send_from_directory
from werkzeug.utils import secure_filename
from ultralytics import YOLO

# Initialize Flask app
app = Flask(__name__)
UPLOAD_FOLDER = "uploads"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Load YOLO model
model = YOLO("C:/Users/Hp/Downloads/best.pt")
class_names = ["Cylinders", "Shock-absorber"]

@app.route('/')
def upload_form():
    return render_template("index.html")

@app.route('/detect', methods=['POST'])
def detect():
    if 'file' not in request.files:
        return "Error: No file uploaded"
    
    file = request.files['file']
    if file.filename == '':
        return "Error: No file selected"

    filename = secure_filename(file.filename)
    filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    file.save(filepath)

    # Run detection
    results = model(filepath)[0]
    detections = sv.Detections.from_ultralytics(results)

    # Filter selected classes
    selected_class_ids = [class_id for class_id, name in model.names.items() if name in class_names]
    filtered_detections = detections[np.isin(detections.class_id, selected_class_ids)]

    # Count detected classes
    class_counts = {name: 0 for name in class_names}
    total_count = 0
    for class_id in filtered_detections.class_id:
        class_name = model.names[class_id]
        if class_name in class_counts:
            class_counts[class_name] += 1
            total_count += 1

    # Load and annotate image
    image = cv2.imread(filepath)
    image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    box_annotator = sv.BoxAnnotator(thickness=3)
    annotated_image = box_annotator.annotate(scene=image, detections=filtered_detections)

    # Save annotated image
    annotated_filename = "annotated_" + filename
    annotated_path = os.path.join(app.config['UPLOAD_FOLDER'], annotated_filename)
    cv2.imwrite(annotated_path, cv2.cvtColor(annotated_image, cv2.COLOR_RGB2BGR))

    # Convert counts to readable text
    count_text = f"Cylinders: {class_counts['Cylinders']}, Shock-absorber: {class_counts['Shock-absorber']}, Total Hazardous Substances : {total_count}"

    return render_template("result.html", count_text=count_text, annotated_filename=annotated_filename)

@app.route('/uploads/<filename>')
def uploaded_file(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

if __name__ == '__main__':
    app.run(debug=True)
