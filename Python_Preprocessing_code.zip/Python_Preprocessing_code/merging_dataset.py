import os
import shutil
import random

# Define paths
base_path = r"C:/Users/Hp/Downloads/merging_folder"
train_folders = ["train1", "train2", "train3", "train4","train5"]

# Consolidated dataset paths
output_path = os.path.join(base_path, "dataset_new")
train_path = os.path.join(output_path, "train")
valid_path = os.path.join(output_path, "valid")
test_path = os.path.join(output_path, "test")

# Create directories
for split in [train_path, valid_path, test_path]:
    os.makedirs(os.path.join(split, "images"), exist_ok=True)
    os.makedirs(os.path.join(split, "labels"), exist_ok=True)

# Collect all images and labels
all_images = []
all_labels = []

for folder in train_folders:
    images_folder = os.path.join(base_path, folder, "images")
    labels_folder = os.path.join(base_path, folder, "labels")

    if os.path.exists(images_folder):
        all_images.extend(
            [(os.path.join(images_folder, f), f) for f in os.listdir(images_folder) if f.endswith((".jpg", ".png"))]
        )

    if os.path.exists(labels_folder):
        all_labels.extend(
            [(os.path.join(labels_folder, f), f) for f in os.listdir(labels_folder) if f.endswith(".txt")]
        )

# Ensure images and labels are sorted correctly
all_images.sort(key=lambda x: x[1])  # Sort by filename
all_labels.sort(key=lambda x: x[1])  # Sort by filename


# Shuffle dataset to ensure randomness
combined = list(zip(all_images, all_labels))
random.shuffle(combined)

# Split dataset
num_total = len(combined)
num_train = int(0.8 * num_total)
num_valid = int(0.1 * num_total)
num_test = num_total - num_train - num_valid  # Remaining images for testing

train_data = combined[:num_train]
valid_data = combined[num_train:num_train + num_valid]
test_data = combined[num_train + num_valid:]

# Function to move files
def move_files(data_list, target_path):
    for (img_src, img_name), (lbl_src, lbl_name) in data_list:
        shutil.copy(img_src, os.path.join(target_path, "images", img_name))
        shutil.copy(lbl_src, os.path.join(target_path, "labels", lbl_name))

# Move files to respective folders
move_files(train_data, train_path)
move_files(valid_data, valid_path)
move_files(test_data, test_path)

print("Dataset split completed!")
